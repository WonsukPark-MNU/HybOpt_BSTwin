%
% Hybrid Optimization Design Approach of Asymmetric
% Base-Isolation Coupling System for Twin Buildings
%
% Fig5-7
%
% Wonsuk Park and Seung-Yong Ok
%
% July 2020
% 
%
clear;
close all;

%% Loading optimal solution and making the twin tower system
load Res_MOS3tt_190810_074233.mat;

hist = 1:length(best_fval_history);
h1 = 1:10;
h2 = 11:300;

figure;set(gcf,'color','white','position',[100,50,1400,800]);
subplot(2,2,1),loglog(hist,best_T1fval_history,'bo:','markersize',8,'linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Iteration');ylabel('J_{PSO}');grid on;ylim([0,1e2]);xlim([0,300]);
title('T_{1}: PSO Results');

subplot(2,2,2),loglog(hist,best_T2fval_history,'rd-.','markersize',8,'linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Iteration');ylabel('J_{GA}');grid on;ylim([0,1e2]);xlim([0,300]);
title('T_{2}: GA Results');

subplot(2,2,3),loglog(hist,best_T3fval_history,'gs--','markersize',8,'linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Iteration');ylabel('J_{HSA}');grid on;ylim([0,1e2]);xlim([0,300]);
title('T_{3}: HSA Results');

subplot(2,2,4),loglog(hist,best_T1fval_history,'bo:','markersize',10);
hold on;loglog(hist,best_T2fval_history,'rd-.',...
    hist,best_T3fval_history,'gs--',...
    hist,best_fval_history,'k-','markersize',8,'linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Iteration');ylabel('J_{All}');grid on;ylim([0,1e2]);xlim([0,300]);
legend('T_{1}: PSO','T_{2}: GA','T_{3}: HSA','Hybrid');
title('Proposed Hybrid Results');

figure;set(gcf,'color','white','position',[100,50,800,600]);
loglog(h2,best_T1fval_history(h2),'bo:','markersize',10);
hold on;loglog(h2,best_T2fval_history(h2),'rd-.',...
    h2,best_T3fval_history(h2),'gs--','markersize',8);
hold on;loglog(h2,best_fval_history(h2),'k-','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Iteration');ylabel('J_{All}');grid on;ylim([0.48,0.55]);xlim([11,300]);
legend('T_{1}: PSO','T_{2}: GA','T_{3}: HSA','Hybrid');

yticks([0.48,0.50,0.52,0.54,0.56]);
yticklabels({'0.48','0.50','0.52','0.54'});
xticks([10,20,30,40,50,100,200,300]);
xticklabels({'10','20','30','40','50','100','200','300'});

itv = 1:maxNoIter;
figure;set(gcf,'color','white','position',[100,50,800,600]);
plot(itv,nPopT1_history,'bo:',itv,nPopT2_history,'rd:',itv,nPopT3_history,'gs--','markersize',4);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Generation');ylabel('No. of Population');
legend('T_{1}: PSO','T_{2}: GA','T_{3}: HSA','Hybrid','location','best');
grid on;


