function  [vd,bi,preFV,resp,PB,Jv,fxj] = optvalue_tt(x)
% Fitness fucntion for MOS Twin Tower
%


% Fixed variables
% control system
% isolator
mb =330*10^3;
%
% Building Sturcuture
%
% Structure Properties
Height = 3.5;     % height of each floor (meters)
ndof = 20;        % number of degree of freedom
no_lfloor = 3;    % number of lower floor
fHeight=Height:Height:ndof*Height;
tdof = ndof*2+1;

% Building 1
% Mass [Kg]
mvec = [665.1*ones(1,no_lfloor) 630.4*ones(1,ndof-no_lfloor)]*10^3;
M1 = diag(mvec);
iM=inv(M1);
% Stiffness [N/m]
kvec = [4.86*ones(1,ndof)]*10^9;
K1=stiffmat(kvec);
% Eigen Analysis and Construct Damping Matrix
[w1,f1,Eivt1]=eigkm(K1,M1);
[ca0,ca1,xi1,C01]=rayDamp2(w1,1,2,0.02,0.02,M1,K1);

% Building 2
M2 = M1;
K2 = K1;
C02 = C01;


% KT filter augmentation
% Input KT filter
% Filter parameters
wg = 2*pi;
xig = 0.5;
S0 = 9; % for H2norm(KTfilter) = 7.5199
% Filter system
Af = [0 1; -wg^2 -2*xig*wg];
Bf = [0; -sqrt(S0)];
Cf = [-wg^2 -2*xig*wg];
Df = 0;

ns = 82;
nf = 2;
nout = 82;
% 
% [ns,~]=size(At);
% [nf,~]=size(Af);
% [nout,~]=size(Ct);
%% Preference Function Values
PrefMax=1.0;% Maximum Function Value
Npwr=2;
alPHa=5;
Nmui=3;% Number of Prefrence Boundary Points
[muiN,~]=bppref(PrefMax,Nmui,Npwr,alPHa);
NprefFn = 4;

PBvalue01=[30 40 60];         % J1 sum d_rms (cm)
PBvalue02=[2.4 3.2 4.8];        % J2 MAX d_rms (cm)
PBvalue03=[100 140 200]*10^3;   % J3 sum VD Force (kN)
PBvalue04=[12 15 20];         % J4 MAX dbase_rms (cm)


    preFV=zeros(7,1);
    % design parameters for control system
    
    % viscous dampers
    vd1vec = x(1:20)*10^8;
    vd2vec = x(21:40)*10^8;
    % connecting damper
    cc = x(41)*10^8;
    % isolator
    kb = x(42)*10^9;
    xib = x(43);
    cb = 2*mb*xib*sqrt(kb/mb);
    

    %
    % Control System
    %
    
    % viscous dampers : inter-story
    Cd1 = stiffmat(vd1vec);
    Cd2 = stiffmat(vd2vec);
    Cd = blkdiag(Cd1,Cd2,0);
    
    % viscous damper : topfloors connection
    Cc = zeros(tdof,tdof);
    Cc(ndof,ndof) = cc;
    Cc(ndof,ndof*2) = -cc;
    Cc(ndof*2,ndof) = -cc;
    Cc(ndof*2,ndof*2) = cc;
    % isolator
    Kb = zeros(tdof,tdof);
    Kb(ndof+1,tdof)=-kvec(1);
    Kb(tdof,ndof+1)=-kvec(1);
    Kb(tdof,tdof)=kvec(1)+kb;
    Cb = zeros(tdof,tdof);
    Cb(ndof+1,tdof)=-vd2vec(1);
    Cb(tdof,ndof+1)=-vd2vec(1);
    Cb(tdof,tdof)=vd2vec(1)+cb;
%     Cb(ndof+1,tdof)=-vd2vec(1)-C02(1,1);
%     Cb(tdof,ndof+1)=-vd2vec(1)-C02(1,1);
%     Cb(tdof,tdof)=vd2vec(1)+C02(1,1)+cb;
    
    % twin tower system
    Ms = blkdiag(M1,M2,mb);
    Ks = blkdiag(K1,K2,0)+Kb;
    Cs = blkdiag(C01,C02,0)+Cd+Cc+Cb;
    iMs = inv(Ms);
    [At,Bt,Ct,Dt]=Ustate3(Ms,iMs,Cs,Ks,0);
    
    % Sys with KT Filter augmentation
    
    Aa = [At Bt*Cf;zeros(nf,ns) Af];
    Ba = [Bt*Df;Bf];
    Ca = [Ct zeros(nout,nf)];
    Da = zeros(nout,1);
    
    %Sys_aug = ss(Aa,Ba,Ca,Da);
    
    %% Performance Indices
    rmsout =  zeros(nout,1);
    for ii = 1:nout
        sys_aug = ss(Aa,Ba,Ca(ii,:),Da(ii,:));
        rmsout(ii) = norm(sys_aug,2);
    end
    
    % rms drifts [cm]
    drms_a = rmsout(1:ndof)*100;
    drms_b = rmsout(ndof+1:2*ndof)*100;
    % rms relative velocities [m/sec]
    vrms_a = rmsout(2*ndof+2:2*ndof+2+ndof-1);
    vrms_b = rmsout(2*ndof+2+ndof:2*ndof+2+ndof+ndof-1);
    % rms base displacemet [cm]
    drms_base = rmsout(2*ndof+1)*100;
    
    % VD forces [kN]
    vdfrms_a = vd1vec'.*vrms_a/1000; %[kN]
    vdfrms_b = vd2vec'.*vrms_b/1000; %[kN]
    
    
    % J1 : sum d_rms [cm]
    J1a = sum(drms_a);
    J1b = sum(drms_b);
    % J2 : max d_rms [cm]
    J2a = max(drms_a);
    J2b = max(drms_b);
    % J3 : sum VD force [kN]
    J3a = sum(vdfrms_a);
    J3b = sum(vdfrms_b);
    % J4 : base_rms [cm]
    J4 = drms_base;
     
    
    %% Preference Function Values
    [preFV(1,1),~] =prfv3(J1a,PBvalue01,muiN,Nmui,Npwr);
    [preFV(2,1),~] =prfv3(J1b,PBvalue01,muiN,Nmui,Npwr);
    [preFV(3,1),~] =prfv3(J2a,PBvalue02,muiN,Nmui,Npwr);
    [preFV(4,1),~] =prfv3(J2b,PBvalue02,muiN,Nmui,Npwr);
    [preFV(5,1),~] =prfv3(J3a,PBvalue03,muiN,Nmui,Npwr);
    [preFV(6,1),~] =prfv3(J3b,PBvalue03,muiN,Nmui,Npwr);
    [preFV(7,1),~] =prfv3(J4,PBvalue04,muiN,Nmui,Npwr);

    
       
    % return


    PFValue=sum(preFV);
    fxj=PFValue/length(preFV);
    
    vd.bld1 = vd1vec;
    vd.bld2 = vd2vec;
    vd.cnct = cc;
    bi.k = kb;
    bi.xi = xib;
    bi.c = cb;
    % rms drifts [cm]
    resp.drms_a = drms_a;
    resp.drms_b = drms_b;
    % rms relative velocities [m/sec]
    resp.vrms_a = vrms_a;
    resp.vrms_b = vrms_b;
    % rms base displacemet [cm]
    resp.drms_base = drms_base;
    % VD forces [kN]
    resp.vdfrms_a = vdfrms_a; %[kN]
    resp.vdfrms_b = vdfrms_b; %[kN]
    % PB
    PB.v1 = PBvalue01;
    PB.v2 = PBvalue02;
    PB.v3 = PBvalue03;
    PB.v4 = PBvalue04;
    % Jv
    Jv = [J1a J1b J2a J2b J3a J3b J4]';

end

