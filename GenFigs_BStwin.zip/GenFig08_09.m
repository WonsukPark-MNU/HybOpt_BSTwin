%
% Hybrid Optimization Design Approach of Asymmetric
% Base-Isolation Coupling System for Twin Buildings
%
% Fig8,9
%
% Wonsuk Park and Seung-Yong Ok
%
% July 2020
% 
%
clear;
close all;

%

load Res_MOS3tt_190810_074233.mat;

%% Optimal Design
[vd,bi,preFV,resp,PB,Jv,fxj] = optvalue_tt(Opt_x);

% Bracing Dampers
% Damping Coeff. [x10^5 kg s/m]
nd = length(vd.bld1);
fprintf('----- Bracing Dampers Damping Coeff. [x10^5 kg s/m] -----\n');
for ii = 1:nd
    fprintf('Cd%d = %6.2f  %6.2f\n',ii,vd.bld1(ii)/10^5, vd.bld2(ii)/10^5);
end

% Coupling Damper
fprintf('----- Coupling Damper Damping Coeff. [x10^5 kg s/m] -----\n');
fprintf('Cc = %6.2f \n',vd.cnct/10^5);

% Base-Isolation Bearing
fprintf('----- Base Isolation Bearing -----\n');
fprintf('kb = %6.2f \n',bi.k/10^6);
fprintf('cb = %6.2f \n',bi.xi*100);

nflr = [0:nd]';
Cd1 = [0;vd.bld1'/1e5];
Cd2 = [0;vd.bld2'/1e5];
Cc = [zeros(nd,1);vd.cnct/1e5];
Cb = [bi.c/1e5;zeros(nd,1)];
Kb = [bi.k/1e6;zeros(nd,1)];

ABiC = [Cd1,Cd2,Cc,Cb];

figure;set(gcf,'color','white','position',[100,50,600,1000]);
barh(nflr,-Cd1,0.5,'BaseValue',0);
hold on;
barh(nflr,Cd2,0.5,'BaseValue',0);
hold on;
barh(nflr,-Cc/2,0.5,'BaseValue',0,'FaceColor','r','EdgeColor','r');
hold on;
barh(nflr,Kb,0.7,'BaseValue',0);
hold on;
barh(nflr,Cb,0.5,'BaseValue',0);
hold on;
barh(nflr,Cc/2,0.5,'BaseValue',0,'FaceColor','r','EdgeColor','r');
hold off;
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Distributions of Dampers & Stiffness');ylabel('Floor');grid on;xlim([-1100,1100]);ylim([-1,21]);
legend('C_{d}^{Bld1}','C_{d}^{Bld2}','C_c','K_b','C_b');
xticks([-1000,-500,0,500,1000]);
xticklabels({'1000','500','0','500','1000'});

%% Initial Design Value

%fxj0 = fitness_tt(P0);
load fxj0_190810_074233.mat;
[min_fxj0, min_idx] = min(fxj0);
[max_fxj0, max_idx] = max(fxj0);

init_x = P0(1,:);
[vd0,bi0,preFV0,resp0,PB,Jv0_min,init_fxj] = optvalue_tt(init_x);

init_x = P0(max_idx,:);
[vd0,bi0,preFV0,resp0,PB,Jv0_max,init_fxj] = optvalue_tt(init_x);


%% Preference Values

%     % J1 : sum d_rms [cm]
%     J1a = sum(drms_a);
%     J1b = sum(drms_b);
%     % J2 : max d_rms [cm]
%     J2a = max(drms_a);
%     J2b = max(drms_b);
%     % J3 : sum VD force [kN]
%     J3a = sum(vdfrms_a);
%     J3b = sum(vdfrms_b);
%     % J4 : base_rms [cm]
%     J4 = drms_base;
%     
%     %% Preference Function Values
%     [preFV(1,1),~] =prfv3(J1a,PBvalue01,muiN,Nmui,Npwr);
%     [preFV(2,1),~] =prfv3(J1b,PBvalue01,muiN,Nmui,Npwr);
%     [preFV(3,1),~] =prfv3(J2a,PBvalue02,muiN,Nmui,Npwr);
%     [preFV(4,1),~] =prfv3(J2b,PBvalue02,muiN,Nmui,Npwr);
%     [preFV(5,1),~] =prfv3(J3a,PBvalue03,muiN,Nmui,Npwr);
%     [preFV(6,1),~] =prfv3(J3b,PBvalue03,muiN,Nmui,Npwr);
%     [preFV(7,1),~] =prfv3(J4,PBvalue04,muiN,Nmui,Npwr);

nJ = length(Jv0_min);
fprintf('\n----- Preference Values ------');
fprintf('\n      Preference Functions                Initial_min   Initial_max     Final(Opt)    c1   c2   c3');
fprintf('\nlambda 1 [rms drift for bldg 1]        %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(1),Jv0_max(1),Jv(1),PB.v1(1),PB.v1(2),PB.v1(3));
fprintf('\nlambda 2 [rms drift for bldg 2]        %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(2),Jv0_max(2),Jv(2),PB.v1(1),PB.v1(2),PB.v1(3));
fprintf('\nlambda 3 [max rms drift for bldg 1]    %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(3),Jv0_max(3),Jv(3),PB.v2(1),PB.v2(2),PB.v2(3));
fprintf('\nlambda 4 [max rms drift for bldg 2]    %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(4),Jv0_max(4),Jv(4),PB.v2(1),PB.v2(2),PB.v2(3));
fprintf('\nlambda 5 [sum d force for bldg 1]      %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(5),Jv0_max(5),Jv(5),PB.v3(1),PB.v3(2),PB.v3(3));
fprintf('\nlambda 6 [sum d force for bldg 2]      %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f',Jv0_min(6),Jv0_max(6),Jv(6),PB.v3(1),PB.v3(2),PB.v3(3));
fprintf('\nlambda 7 [rms displ. for bldg 2 base]  %10.2f    %10.2f     %10.2f  %4.0f %4.0f %4.0f\n',Jv0_min(7),Jv0_max(7),Jv(7),PB.v4(1),PB.v4(2),PB.v4(3));


cmat = [0 30   40   60 80;
    0 30   40   60 80;
    0 2.4   3.2   4.8 7;
    0 2.4   3.2   4.8 7;
    0 100000 140000 200000 260000
    0 100000 140000 200000 260000
    0 12    15  20  200];

for ii = 1:7
    l0_min = Jv0_min(ii);
    l0_max = Jv0_max(ii);
    lf = Jv(ii);
    idx0_min = max(find(l0_min > cmat(ii,:)));
    idx0_max = max(find(l0_max > cmat(ii,:)));
    idxf = max(find(lf > cmat(ii,:)));
            
    nP0_min(ii) = (idx0_min-1) + (l0_min-cmat(ii,idx0_min))/(cmat(ii,idx0_min+1)-cmat(ii,idx0_min));
    nP0_max(ii) = (idx0_max-1) + (l0_max-cmat(ii,idx0_max))/(cmat(ii,idx0_max+1)-cmat(ii,idx0_max));
    nPf(ii) = (idxf-1) + (lf-cmat(ii,idxf))/(cmat(ii,idxf+1)-cmat(ii,idxf));
end

n_Jm = [7:-1:1]';
c1 = [1,1];yc1 = [0,8];
c2 = [2,2];yc2 = [0,8];
c3 = [3,3];yc3 = [0,8];

%
figure;set(gcf,'color','white','position',[100,50,1200,800]);
plot(nP0_min,n_Jm,'bo',nPf,n_Jm,'ro','markersize',16);
hold on;
plot(c1,yc1,'k:',c2,yc2,'k:',c3,yc3,'k:','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Preferences');ylabel('Measures');
legend('Initial Solution','Optimal Solution','location','northwest');
grid off;xlim([0 4]);ylim([0 8]);
xticks([1,2,3]);
xticklabels({'c_{l1}','c_{l2}','c_{l3}'});
yticks([1,2,3,4,5,6,7]);
yticklabels({'\lambda_{7}(cm)','\lambda_{6}(MN)','\lambda_{5}(MN)','\lambda_{4}(cm)'...
    ,'\lambda_{3}(cm)','\lambda_{2}(cm)','\lambda_{1}(cm)'});
title(['very desirble           desirable            acceptable          unacceptable']);

text(0.95,6.8,'30','fontsize',18);
text(1.95,6.8,'40','fontsize',18);
text(2.95,6.8,'60','fontsize',18);
text(0.95,5.8,'30','fontsize',18);
text(1.95,5.8,'40','fontsize',18);
text(2.95,5.8,'60','fontsize',18);
text(0.97,4.8,'2','fontsize',18);
text(1.97,4.8,'3','fontsize',18);
text(2.97,4.8,'5','fontsize',18);
text(0.97,3.8,'2','fontsize',18);
text(1.97,3.8,'3','fontsize',18);
text(2.97,3.8,'5','fontsize',18);
text(0.93,2.8,'100','fontsize',18);
text(1.93,2.8,'140','fontsize',18);
text(2.93,2.8,'200','fontsize',18);
text(0.93,1.8,'100','fontsize',18);
text(1.93,1.8,'140','fontsize',18);
text(2.93,1.8,'200','fontsize',18);
text(0.95,0.8,'12','fontsize',18);
text(1.95,0.8,'15','fontsize',18);
text(2.95,0.8,'20','fontsize',18);

text(3.15,7.3,'66.18','fontsize',24);
text(2.7,7.3,'56.90','fontsize',24);
text(2.35,5.7,'47.50','fontsize',24);
text(2.05,6.3,'43.40','fontsize',24);
text(2.90,5.3,'4.78','fontsize',24);
text(2.55,5.3,'4.25','fontsize',24);
text(2.63,4.3,'4.38','fontsize',24);
text(2.28,4.3,'3.82','fontsize',24);
text(2.86,3.3,'199.1','fontsize',24);
text(1.88,3.3,'140.0','fontsize',24);
text(2.10,1.7,'149.2','fontsize',24);
text(1.84,2.3,'139.4','fontsize',24);
text(2.92,1.3,'22.3','fontsize',24);
text(2.65,1.3,'18.8','fontsize',24);

%
figure;set(gcf,'color','white','position',[100,50,1200,800]);
plot(nP0_max,n_Jm,'bo',nPf,n_Jm,'ro','markersize',16);
hold on;
plot(c1,yc1,'k:',c2,yc2,'k:',c3,yc3,'k:','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Preferences');ylabel('Measures');
legend('Initial Solution','Optimal Solution','location','northwest');
grid off;xlim([0 4]);ylim([0 8]);
xticks([1,2,3]);
xticklabels({'c_{l1}','c_{l2}','c_{l3}'});
yticks([1,2,3,4,5,6,7]);
yticklabels({'\lambda_{7}(cm)','\lambda_{6}(MN)','\lambda_{5}(MN)','\lambda_{4}(cm)'...
    ,'\lambda_{3}(cm)','\lambda_{2}(cm)','\lambda_{1}(cm)'});
title(['very desirble           desirable            acceptable          unacceptable']);

text(0.95,6.8,'30','fontsize',18);
text(1.95,6.8,'40','fontsize',18);
text(2.95,6.8,'60','fontsize',18);
text(0.95,5.8,'30','fontsize',18);
text(1.95,5.8,'40','fontsize',18);
text(2.95,5.8,'60','fontsize',18);
text(0.97,4.8,'2','fontsize',18);
text(1.97,4.8,'3','fontsize',18);
text(2.97,4.8,'5','fontsize',18);
text(0.97,3.8,'2','fontsize',18);
text(1.97,3.8,'3','fontsize',18);
text(2.97,3.8,'5','fontsize',18);
text(0.93,2.8,'100','fontsize',18);
text(1.93,2.8,'140','fontsize',18);
text(2.93,2.8,'200','fontsize',18);
text(0.93,1.8,'100','fontsize',18);
text(1.93,1.8,'140','fontsize',18);
text(2.93,1.8,'200','fontsize',18);
text(0.95,0.8,'12','fontsize',18);
text(1.95,0.8,'15','fontsize',18);
text(2.95,0.8,'20','fontsize',18);

text(2.15,7.3,'45.98','fontsize',24);
text(2.7,7.3,'56.90','fontsize',24);
text(0.50,6.3,'4.25','fontsize',24);
text(2.05,6.3,'43.40','fontsize',24);
text(1.38,5.3,'2.79','fontsize',24);
text(2.55,5.3,'4.25','fontsize',24);
text(0.55,4.3,'1.58','fontsize',24);
text(2.28,4.3,'3.82','fontsize',24);
text(0.72,3.3,'82.1','fontsize',24);
text(1.88,3.3,'140.0','fontsize',24);
text(0.38,2.3,'49.0','fontsize',24);
text(1.85,2.3,'139.4','fontsize',24);
text(3.73,1.3,'177.7','fontsize',24);
text(2.65,1.3,'18.8','fontsize',24);


nP0_min
nP0_max
nPf
Jv0_min'
Jv0_max'
Jv'

