% evaluate preference value

function [py,pxx]=prfv3(px,P,x,r,n)

if px <= P(1)
    pxx=x(1)/P(1)*px;
    py=(pxx)^n;
elseif px>P(r)
    pxx=x(r)/P(r)*px;
    py=(10*(pxx+1.0))^n;%py=(pxx)^(n+1);
else
    for j=2:r
        if px>P(j-1) & px <= P(j)
            pxx=(x(j)-x(j-1))/(P(j)-P(j-1))*(px-P(j-1))+x(j-1);
            py=(pxx)^n;
            break
        end
    end
end