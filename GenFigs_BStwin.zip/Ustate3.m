function [A0,Bw,C_0,D0]=Ustate3(M,iM,C,K,ltype)
% function program for constitution of state equation to make A,B,C,D matrix
% ltype = 0 in case of Earthquake
% ltype = 1 in case of Wind
%
% Ustate3 
%   - output : rel. disp. & vel.
%   - dof    : [x1 x2 xb]'
%
[~,n]=size(M);
n1 = (n-1)/2;
n2 = n1;
O1=zeros(n,n);
O3=zeros(n,1);
I=eye(n,n);
A0=[O1 I;-iM*K -iM*C];
if ltype==0
    Bw=[O3;-ones(n,1)];
    D0=zeros(2*n,1);
    C0=eye(n,n);
    for j=2:n1
        C0(j,j-1)=-1;
    end
    for j=n1+2:n-1
        C0(j,j-1)=-1;
    end
    C0(n1+1,n)=-1;
    %C0=[C0 zeros(n,n)]; % Relative Story Drift
    C_0 = blkdiag(C0,C0); % Relative Story Drift & vel
elseif ltype==1
    Bw=[O1;iM];
    D0=iM;
    C_0=[-iM*K -iM*C];
else
    disp('Loading type error !!!')
end