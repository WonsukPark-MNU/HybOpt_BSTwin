%
% Hybrid Optimization Design Approach of Asymmetric
% Base-Isolation Coupling System for Twin Buildings
%
% Fig14
%
% Wonsuk Park and Seung-Yong Ok
%
% July 2020
% 
%
clear;
close all;

%% Uncontrolled system
unc_x = zeros(1,40);


%% Plot
load para_data2.mat;

% (1) Building 1 rms
figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(alphaC,sumrms1_a','*:',alphaC,sumrms2_a','*:',alphaC,sumrms3_a','o:'...
    ,alphaC,sumrms5_a','d:',alphaC,sumrms4_a','s:'...
    ,[alphaC(1) alphaC(end)],sum(resp.drms_a)*[1 1],'k-','linewidth',2,'markersize',10);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Cost factor {\alpha_c}');
ylabel('\lambda_{1}(cm)');
title('Building 1');
legend('c_{d1~d20}','c_{d21~22}','c_c','c_b','k_b','ABiC','location','southeast');
xlim([0 2]);grid on;

% (2) Building 2 rms
figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(alphaC,sumrms1_b','*:',alphaC,sumrms2_b','*:',alphaC,sumrms3_b','o:'...
    ,alphaC,sumrms5_b','d:',alphaC,sumrms4_b','s:'...
    ,[alphaC(1) alphaC(end)],sum(resp.drms_b)*[1 1],'k-','linewidth',2,'markersize',10);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
legend('c_{d1~d20}','c_{d21~22}','c_c','c_b','k_b','ABiC','location','southeast');
xlabel('Cost factor {\alpha_c}');
ylabel('\lambda_{2}(cm)');
title('Building 2');
xlim([0 2]);grid on;
% (3) rms displacement of building 2 base

figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(alphaC,rmsbase1','*:',alphaC,rmsbase2','*:',alphaC,rmsbase3','o:'...
    ,alphaC,rmsbase5','d:',alphaC,rmsbase4','s:'...
    ,[alphaC(1) alphaC(end)],sum(resp.drms_base)*[1 1],'k-','linewidth',2,'markersize',10);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
legend('c_{d1~d20}','c_{d21~22}','c_c','c_b','k_b','ABiC','location','northeast');
xlabel('Cost factor {\alpha_c}');
ylabel('\lambda_{7}(cm)');
title('Isolator');
xlim([0 2]);grid on;




 


