function [X,Y]=stairplotxy(xv,yv)
%
% [X,Y]=stairplotxy(xv,yv)
%
% Aug 17, 2015 Wonsuk Park
%
nfloor = length(xv);
X = zeros(nfloor,1)*2;
Y = zeros(nfloor,1)*2;
xv = cumsum(xv);
X(1,1)=0;
for ii = 1:nfloor-1
    X(ii*2)=xv(ii);
    X(ii*2+1)=xv(ii);
    Y(ii*2-1)=yv(ii);
    Y(ii*2)=yv(ii);
end
X(nfloor*2,1)=xv(nfloor);
Y(nfloor*2-1,1)=yv(nfloor);
Y(nfloor*2,1)=yv(nfloor);


