function [ny,nd1,nd2,nrd,na,nVb1,nVb2,nMb1,nMb2,topd1,topa1,bs1]=response1(ndof,tdof,fHeight,iMs,Ks,Cs,y_eq01,x_eq01,EarthAcc01);
%
% Seismic Responses for Twin Buildings
%


% displacements wrt ground
d1_eq01 = cumsum(y_eq01(:,1:20),2);
d2_eq01 = cumsum([y_eq01(:,41) y_eq01(:,21:40)],2);
% rel. disp. btw two buildings
rd_eq01 = d2_eq01(:,2:21) - d1_eq01;
%fprintf('Min. relative displ. %f \n',min(rd_eq01,[],1));

% Floor accelerations
a_eq01 = [-iMs*Ks -iMs*Cs]*x_eq01' + ones(tdof,1)*EarthAcc01;
a_eq01 = a_eq01';

% Base shear
Vf1 = Ks(1:ndof,1:ndof)*x_eq01(:,1:ndof)'+Cs(1:ndof,1:ndof)*x_eq01(:,tdof+1:tdof+ndof)'; % B#1 floor shear force

if 2*ndof == tdof
    Vf2 = Ks(ndof+1:2*ndof,ndof+1:2*ndof)*x_eq01(:,ndof+1:2*ndof)'+...
        Cs(ndof+1:2*ndof,ndof+1:2*ndof)*x_eq01(:,tdof+ndof+1:2*tdof)'; % B#2 floor shear force
else
    Vf2 = Ks(ndof+1:2*ndof+1,ndof+1:2*ndof+1)*x_eq01(:,ndof+1:2*ndof+1)'+...
        +Cs(ndof+1:2*ndof+1,ndof+1:2*ndof+1)*x_eq01(:,tdof+ndof+1:2*tdof)'; % B#2 floor shear force with base ioslator
end 
Vbase1 = sum(Vf1,1); % B#1 Base Shear Time History
Vbase2 = sum(Vf2,1); % B#2 Base Shear Time History

% Overturning Moment
Mbase1 = fHeight*Vf1;% B#1 Base Moment Time History
isolh = 0.5;    % Height of Base Isolator

if 2*ndof == tdof
    Mbase2 = fHeight*Vf2;% B#1 Base Moment Time History
else
    Mbase2 = [fHeight+isolh isolh]*Vf2;% B#2 Base Moment Time History
end


% return
ny = y_eq01;
nd1 = d1_eq01; % B#1 displ
nd2 = d2_eq01; % B#2 displ
nrd = rd_eq01; % rel. disp. btw two buildings
na = a_eq01; % Floor accelerations
nVb1 = Vbase1; % B#1 Base Shear Time History
nVb2 = Vbase2; % B#2 Base Shear Time History
nMb1 = Mbase1; % B#1 Base Moment Time History
nMb2 = Mbase2; % B#2 Base Moment Time History
topd1 = max(abs(d1_eq01(:,20)));
% topd2_eq01 = max(abs(d2_eq01(:,20)));
topa1 = max(abs(a_eq01(:,20)));
bs1 = max(abs(Vbase1));

return
