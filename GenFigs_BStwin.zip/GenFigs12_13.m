%
% Hybrid Optimization Design Approach of Asymmetric
% Base-Isolation Coupling System for Twin Buildings
%
% Fig12,13
%
% Wonsuk Park and Seung-Yong Ok
%
% July 2020
% 
%
close all;
clear all;
warning off;

%% Uncontrolled system
unc_x = zeros(1,40);
[vdu,preFVu,respu,PBu,Jvu] = compvalue_tt(unc_x);

%% Comparative design
comp_x = 7/20*ones(1,40); % 350 [x10^5 kg s/m]
[vd0,preFV0,resp0,PB0,Jv0] = compvalue_tt(comp_x);

%% Optimal Design
% Loading optimal solution and making the twin tower system

load Res_MOS3tt_190810_074233.mat;
[vd,bi,preFV,resp,PB,Jv,fxj] = optvalue_tt(Opt_x);

%% rms Response Plot (KT Filter system)
%

storyv = 1:20;
[drmsa_unc_stair,stairy]=stairplotxy(respu.drms_a,storyv);
[drmsa_0_stair,stairy]=stairplotxy(resp0.drms_a,storyv);
[drmsa_opt_stair,stairy]=stairplotxy(resp.drms_a,storyv);

[drmsb_unc_stair,stairy]=stairplotxy(respu.drms_b,storyv);
[drmsb_0_stair,stairy]=stairplotxy(resp0.drms_b,storyv);
[drmsb_opt_stair,stairy]=stairplotxy(resp.drms_b,storyv);

figure;set(gcf,'color','white','position',[100,50,1400,800]);
subplot(1,2,1);plot(drmsa_unc_stair,stairy,'k',drmsa_0_stair,stairy,'b',drmsa_opt_stair,stairy,'r','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('r.m.s. drift(cm)');ylabel('Floor');title('Building 1');
legend('UNC','iUDC','ABiC','Location','southeast');
xlim([0 120]);ylim([0 21]);grid on;
subplot(1,2,2);plot(drmsb_unc_stair,stairy,'k',drmsb_0_stair,stairy,'b',drmsb_opt_stair,stairy,'r','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('r.m.s. drift(cm)');ylabel('Floor');title('Building 2');
legend('UNC','iUDC','ABiC','Location','southeast');
xlim([0 120]);ylim([0 21]);grid on;

%%
%
% Structure Properties
%
Height = 3.5;     % height of each floor (meters)
ndof = 20;        % number of degree of freedom
no_lfloor = 3;    % number of lower floor
fHeight=Height:Height:ndof*Height;
tdof = ndof*2+1;
% Building 1
% Mass [Kg]
mvec = [665.1*ones(1,no_lfloor) 630.4*ones(1,ndof-no_lfloor)]*10^3;
M1 = diag(mvec);
iM=inv(M1);
% Stiffness [N/m]
kvec = 4.86*ones(1,ndof)*10^9;
K1=stiffmat(kvec);
% Eigen Analysis and Construct Damping Matrix
[w1,f1,Eivt1]=eigkm(K1,M1);
[ca0,ca1,xi1,C01]=rayDamp2(w1,1,2,0.02,0.02,M1,K1);
% Building 2
M2 = M1;
K2 = K1;
C02 = C01;

%
% Optimal Control System
%
% viscous dampers
vd1vec = Opt_x(1:20)*10^8;
vd2vec = Opt_x(21:40)*10^8;
% connecting damper
cc = Opt_x(41)*10^8;
% isolator
mb =330*10^3;
kb = Opt_x(42)*10^9;
xib = Opt_x(43);
cb = 2*mb*xib*sqrt(kb/mb);

% viscous dampers : inter-story
Cd1 = stiffmat(vd1vec);
Cd2 = stiffmat(vd2vec);
Cd = blkdiag(Cd1,Cd2,0);

% viscous damper : topfloors connection
Cc = zeros(tdof,tdof);
Cc(ndof,ndof) = cc;
Cc(ndof,ndof*2) = -cc;
Cc(ndof*2,ndof) = -cc;
Cc(ndof*2,ndof*2) = cc;
% isolator
Kb = zeros(tdof,tdof);
Kb(ndof+1,tdof)=-kvec(1);
Kb(tdof,ndof+1)=-kvec(1);
Kb(tdof,tdof)=kvec(1)+kb;
Cb = zeros(tdof,tdof);
Cb(ndof+1,tdof)=-vd2vec(1);
Cb(tdof,ndof+1)=-vd2vec(1);
Cb(tdof,tdof)=vd2vec(1)+cb;
%
%% Twin Tower System - Hybrid Control
%
Ms = blkdiag(M1,M2,mb);
Ks = blkdiag(K1,K2,0)+Kb;
Cs = blkdiag(C01,C02,0)+Cd+Cc+Cb;
iMs = inv(Ms);
[At,Bt,Ct,Dt]=Ustate3(Ms,iMs,Cs,Ks,0); % Ct for story drift(&vel) outputs
TTCsysEQ=ss(At,Bt,Ct,Dt);

%% Twin Tower System - Uncontrolled
Mu = blkdiag(M1,M2);
Ku = blkdiag(K1,K2);
Cu = blkdiag(C01,C02);
iMu = inv(Mu);
[Au,Bu,C_u,Du]=Ustate4(Mu,iMu,Cu,Ku,0);
TTUsysEQ=ss(Au,Bu,C_u,Du);

%% Twin Tower System - Uniform Damper
    % viscous dampers : inter-story
    comp_x = 7/20*ones(1,40); % 350 [x10^5 kg s/m]
    vd1vec = comp_x(1:20)*10^8;
    vd2vec = comp_x(21:40)*10^8;
    Cd1u = stiffmat(vd1vec);
    Cd2u = stiffmat(vd2vec);
    Cdu = blkdiag(Cd1u,Cd2u);
    C_0 = Cu+Cdu;
[A0,B0,C0,D0]=Ustate4(Mu,iMu,C_0,Ku,0);   
TT0sysEQ=ss(A0,B0,C0,D0);


    
%% Seismic Response Time History Analysis 

% El Centro (PGA = 0.4g)
load('elcenEQ04g.mat','dt','elcen04','t');
EarthAcc01=elcen04;
t_eq01=t;
load('mexicoEQ04g.mat','dt','mexico04','t');
EarthAcc02=mexico04;
t_eq02=t;
load('northEQ04g.mat','dt','northR04','t');
EarthAcc03=northR04;
t_eq03=t;


%% Twin Tower System - Hybrid Control
[y_eq01,~,x_eq01]=lsim(TTCsysEQ,EarthAcc01,t_eq01);
[y_eq02,~,x_eq02]=lsim(TTCsysEQ,EarthAcc02,t_eq02);
[y_eq03,~,x_eq03]=lsim(TTCsysEQ,EarthAcc03,t_eq03);
% Story drift
%
% y_eq01 4998*82
%
% col  1~20 : drift 1st story ~ 20th story (Building #1)
% col 21~40 : drift 1st story ~ 20th story (Building #2)
% col    41 : displ. isolator (Building #2)
% col 42~61 : rel. vel. 1st story ~ 20th story (Building #1)
% col 62~81 : rel. vel. 1st story ~ 20th story (Building #2)
% col    82 : rel. vel. isolator (Building #2)
[y_e1,d1_e1,d2_e1,rd_e1,a_e1,Vb1_e1,Vb2_e1,Mb1_e1,Mb2_e1,topd1_e1,topa1_e1,bs1_e1]=response1(ndof,tdof,fHeight,iMs,Ks,Cs,y_eq01,x_eq01,EarthAcc01);
[y_e2,d1_e2,d2_e2,rd_e2,a_e2,Vb1_e2,Vb2_e2,Mb1_e2,Mb2_e2,topd1_e2,topa1_e2,bs1_e2]=response1(ndof,tdof,fHeight,iMs,Ks,Cs,y_eq02,x_eq02,EarthAcc02);
[y_e3,d1_e3,d2_e3,rd_e3,a_e3,Vb1_e3,Vb2_e3,Mb1_e3,Mb2_e3,topd1_e3,topa1_e3,bs1_e3]=response1(ndof,tdof,fHeight,iMs,Ks,Cs,y_eq03,x_eq03,EarthAcc03);

%% Twin Tower System - Uncontrolled
[yu_eq01,~,xu_eq01]=lsim(TTUsysEQ,EarthAcc01,t_eq01);
[yu_eq02,~,xu_eq02]=lsim(TTUsysEQ,EarthAcc02,t_eq02);
[yu_eq03,~,xu_eq03]=lsim(TTUsysEQ,EarthAcc03,t_eq03);
% Story drift
%
% yu_eq01 4998*80
%
% col  1~20 : drift 1st story ~ 20th story (Building #1)
% col 21~40 : drift 1st story ~ 20th story (Building #2)
% col 41~60 : rel. vel. 1st story ~ 20th story (Building #1)
% col 61~80 : rel. vel. 1st story ~ 20th story (Building #2)
[yu_e1,d1u_e1,d2u_e1,rdu_e1,au_e1,Vb1u_e1,Vb2u_e1,Mb1u_e1,Mb2u_e1,topd1u_e1,topa1u_e1,bs1u_e1]=response1(ndof,ndof*2,fHeight,iMu,Ku,Cu,yu_eq01,xu_eq01,EarthAcc01);
[yu_e2,d1u_e2,d2u_e2,rdu_e2,au_e2,Vb1u_e2,Vb2u_e2,Mb1u_e2,Mb2u_e2,topd1u_e2,topa1u_e2,bs1u_e2]=response1(ndof,ndof*2,fHeight,iMu,Ku,Cu,yu_eq02,xu_eq02,EarthAcc02);
[yu_e3,d1u_e3,d2u_e3,rdu_e3,au_e3,Vb1u_e3,Vb2u_e3,Mb1u_e3,Mb2u_e3,topd1u_e3,topa1u_e3,bs1u_e3]=response1(ndof,ndof*2,fHeight,iMu,Ku,Cu,yu_eq03,xu_eq03,EarthAcc03);

%% Twin Tower System - Uniform Damper
[y0_eq01,~,x0_eq01]=lsim(TT0sysEQ,EarthAcc01,t_eq01);
[y0_eq02,~,x0_eq02]=lsim(TT0sysEQ,EarthAcc02,t_eq02);
[y0_eq03,~,x0_eq03]=lsim(TT0sysEQ,EarthAcc03,t_eq03);
% Story drift
%
% y0_eq01 4998*80
%
% col  1~20 : drift 1st story ~ 20th story (Building #1)
% col 21~40 : drift 1st story ~ 20th story (Building #2)
% col 41~60 : rel. vel. 1st story ~ 20th story (Building #1)
% col 61~80 : rel. vel. 1st story ~ 20th story (Building #2)
[y0_e1,d10_e1,d20_e1,rd0_e1,a0_e1,Vb10_e1,Vb20_e1,Mb10_e1,Mb20_e1,topd10_e1,topa10_e1,bs10_e1]=response1(ndof,ndof*2,fHeight,iMu,Ku,C_0,y0_eq01,x0_eq01,EarthAcc01);
[y0_e2,d10_e2,d20_e2,rd0_e2,a0_e2,Vb10_e2,Vb20_e2,Mb10_e2,Mb20_e2,topd10_e2,topa10_e2,bs10_e2]=response1(ndof,ndof*2,fHeight,iMu,Ku,C_0,y0_eq02,x0_eq02,EarthAcc02);
[y0_e3,d10_e3,d20_e3,rd0_e3,a0_e3,Vb10_e3,Vb20_e3,Mb10_e3,Mb20_e3,topd10_e3,topa10_e3,bs10_e3]=response1(ndof,ndof*2,fHeight,iMu,Ku,C_0,y0_eq03,x0_eq03,EarthAcc03);


%% Plot

% Max. drift (cm) for El Centro (e1)
r_dmax_a_e1 = max(abs(y_e1(:,1:20)))*100;
ru_dmax_a_e1 =  max(abs(yu_e1(:,1:20)))*100;
r0_dmax_a_e1 =  max(abs(y0_e1(:,1:20)))*100;

storyv = 1:20;
[dmaxa_unc_stair,stairy]=stairplotxy(ru_dmax_a_e1,storyv);
[dmaxa_0_stair,stairy]=stairplotxy(r0_dmax_a_e1,storyv);
[dmaxa_opt_stair,stairy]=stairplotxy(r_dmax_a_e1,storyv);

figure;set(gcf,'color','white','position',[100,50,1400,800]);
subplot(1,2,1);plot(dmaxa_unc_stair,stairy,'k',dmaxa_0_stair,stairy,'b',dmaxa_opt_stair,stairy,'r','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
legend('Uncontrolled','Uniform','Hybrid','Location','southeast');
xlabel('Max. Drift(cm)');ylabel('Floor');title('Building 1 subjected to El Centro Eq.');ylabel('Floor');
legend('UNC','iUDC','ABiC','Location','southeast');
xlim([0 30]);ylim([0 21]);grid on;

r_dmax_b_e1 = max(abs(y_e1(:,21:40)))*100;
ru_dmax_b_e1 =  max(abs(yu_e1(:,21:40)))*100;
r0_dmax_b_e1 =  max(abs(y0_e1(:,21:40)))*100;

storyv = 1:20;
[dmaxb_unc_stair,stairy]=stairplotxy(ru_dmax_b_e1,storyv);
[dmaxb_0_stair,stairy]=stairplotxy(r0_dmax_b_e1,storyv);
[dmaxb_opt_stair,stairy]=stairplotxy(r_dmax_b_e1,storyv);

subplot(1,2,2);plot(dmaxb_unc_stair,stairy,'k',dmaxb_0_stair,stairy,'b',dmaxb_opt_stair,stairy,'r','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Max. Drift(cm)');ylabel('Floor');title('Building 2 subjected to El Centro Eq.');ylabel('Floor');
legend('UNC','iUDC','ABiC','Location','southeast');
xlim([0 30]);ylim([0 21]);grid on;

%% Time history
figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(t_eq01,d1u_e1(:,20)*100,'k:',t_eq01,d10_e1(:,20)*100,'b-.',t_eq01,d1_e1(:,20)*100,'r-','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Time(sec)');
ylabel('Top floor displacement(cm)');
title('Building 1 subjected to El Centro Eq.');
legend('UNC','iUDC','ABiC','Location','northeast');grid on;

figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(t_eq01,d2u_e1(:,20),'k:',t_eq01,d20_e1(:,20),'b-.',t_eq01,d2_e1(:,20),'r-','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Time(sec)');
ylabel('Top floor displacement(cm)');
title('Building 2 subjected to El Centro Eq.');
legend('UNC','iUDC','ABiC','Location','northeast');grid on;

figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(t_eq01,Vb1u_e1,'k:',t_eq01,Vb10_e1,'b-.',t_eq01,Vb1_e1,'r-','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Time(sec)');
ylabel('Base shear force(kN)');
title('Building 1 subjected to El Centro Eq.');
legend('UNC','iUDC','ABiC','Location','northeast');grid on;

figure;set(gcf,'color','white','position',[100,50,1400,800]);
plot(t_eq01,Vb2u_e1,'k:',t_eq01,Vb20_e1,'b-.',t_eq01,Vb2_e1,'r-','linewidth',2);
set(gca,'fontname','TimesNewRoman','fontsize',24,'linewidth',2);
xlabel('Time(sec)');
ylabel('Base shear force(kN)');
title('Building 2 subjected to El Centro Eq.');
legend('UNC','iUDC','ABiC','Location','northeast');grid on;



