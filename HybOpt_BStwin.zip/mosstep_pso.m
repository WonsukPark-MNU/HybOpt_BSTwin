function [offSpring,Velocities] = mosstep_pso(noIndiv,currPop,currFval,Objfcn,nvars,lb,ub,...
        IndividualBestPositions,IndividualBestFvals,Velocities,...
        adaptiveNeighborhoodSize,adaptiveInertia,bestFvals,options)
%
% MOS technique subroutine
%
% Offspring by Particle Swarm Optimization with dynamic population
% 
% Feb 16, 2017
% Wonsuk Park
%


numParticles = noIndiv;


%% Args lb & ub
[lbColumn, ubColumn, msg, exitFlag] = checkbound(lb, ub, nvars);
% checkbound returns column vectors, but we to convert that to a row vector
% and repeat it across SwarmSize rows.
lbRow = lbColumn';
ubRow = ubColumn';
cSelf = options.SelfAdjustment;
cSocial = options.SocialAdjustment;

lbMatrix = repmat(lbRow, numParticles, 1);
ubMatrix = repmat(ubRow, numParticles, 1);

options.TolFunValue=1E-06;

% Enforce bounds
if any(any(currPop < lbMatrix)) || any(any(currPop > ubMatrix))
    currPop = max(lbMatrix, currPop);
    currPop = min(ubMatrix, currPop);
end


%% Create Offsprings (next step positon)

% Generate a random neighborhood for each particle that includes
        % the particle itself
        if adaptiveNeighborhoodSize > numParticles
            adaptiveNeighborhoodSize = numParticles;
        end
        neighborIndex = zeros(numParticles, adaptiveNeighborhoodSize);
        neighborIndex(:, 1) = 1:numParticles; % First neighbor is self
        for i = 1:numParticles
            % Determine random neighbors that exclude the particle itself,
            % which is (numParticles-1) particles
            neighbors = randperm(numParticles-1, adaptiveNeighborhoodSize-1);
            % Add 1 to indicies that are >= current particle index
            iShift = neighbors >= i;
            neighbors(iShift) = neighbors(iShift) + 1;
            neighborIndex(i,2:end) = neighbors;
        end
        % Identify the best neighbor
        [~, bestRowIndex] = min(IndividualBestFvals(neighborIndex), [], 2);
        % Create the linear index into neighborIndex
        bestLinearIndex = (bestRowIndex.'-1).*numParticles + (1:numParticles);
        bestNeighborIndex = neighborIndex(bestLinearIndex);
        randSelf = rand(numParticles, nvars);
        randSocial = rand(numParticles, nvars);

        % Note that velocities and positions can become infinite if the
        % inertia range is too large or if the objective function is badly
        % behaved.

        % Update the velocities
        newVelocities = adaptiveInertia*Velocities + ...
            cSelf*randSelf.*(IndividualBestPositions-currPop) + ...
            cSocial*randSocial.*(IndividualBestPositions(bestNeighborIndex, :)-currPop);
        tfValid = all(isfinite(newVelocities), 2);
        Velocities(tfValid,:) = newVelocities(tfValid,:);
        % Update the positions
        newPopulation = currPop + Velocities;
        tfInvalid = ~isfinite(newPopulation);
        newPopulation(tfInvalid) = currPop(tfInvalid);
        % Enforce bounds, setting the corresponding velocity component to
        % zero if a particle encounters a lower/upper bound
        tfInvalid = newPopulation < lbMatrix;
        if any(tfInvalid(:))
            newPopulation(tfInvalid) = lbMatrix(tfInvalid);
            Velocities(tfInvalid) = 0;
        end
        tfInvalid = newPopulation > ubMatrix;
        if any(tfInvalid(:))
            newPopulation(tfInvalid) = ubMatrix(tfInvalid);
            Velocities(tfInvalid) = 0;
        end
        offSpring = newPopulation;
        
 




end
