function range = rangeCorrection(nvars,range)
%rangeCorrection Check the size of a range variable
range = reshape(range, 1, []); % Want row vector

% Perform scalar expansion, if required
if isscalar(range)
    range = repmat(range, 1, nvars);
end

% Check vector size
if ~isvector(range) || numel(range) ~= nvars
    error(message('globaloptim:particleswarm:invalidInitialSwarmSpan'));  
end

% Check for inf/nan range
if ~all(isfinite(range)) 
   error(message('globaloptim:particleswarm:nonFiniteInitialSwarmSpan'));
end
end % range correction
