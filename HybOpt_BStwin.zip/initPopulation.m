function x0=initPopulation(nvars,lb,ub,PopulationSize)

x0 = zeros(PopulationSize,nvars);
for ii = 1:nvars
    x0(:,ii)= lb(ii) + (ub(ii)-lb(ii)).*rand(PopulationSize,1);
end

 
