function [options,objfcn]  = validateOptions(userOptions,nvars,objfcn,lb,ub)
% Most validation should have been performed by optim.options.checkfield.
% Additional validation includes:
%   * Validate options that depend on input arguments, like nvars.
%   * Validate options that depend on other options, like SwarmSize.
%   * Convert to numbers options that are strings.

if ~isa(userOptions, 'optim.options.SolverOptions')
    error(message('globaloptim:particleswarm:invalidOptionsInputs'));
end
userOptions = convertForSolver(userOptions, 'Particleswarm');
options = extractOptionsStructure(userOptions);

% Overwrite the default creation function for deployment.
if strcmp(func2str(isFcn(options.CreationFcn)),'pswcreationuniform')
    options.CreationFcn = @pswcreationuniform;
end

% Determine the verbosity
switch  options.Display
    case {'off','none'}
        options.Verbosity = 0;
    case 'final'
        options.Verbosity = 1;
    case 'iter'
        options.Verbosity = 2;
end

% SwarmSize (see optim options checkfield.m and Particleswarm.m)
if ischar(options.SwarmSize)
    % This should only be the magic string 'min(100,10*numberofvariables)'
    options.SwarmSize = min(100,10*nvars);
end

% MaxIter has several hard-coded string values that match the following
% format string (as enforced in checkfield.m):
nvarFormatStr = '%d*numberofvariables';

% MaxIter validation
if ischar(options.MaxIter)
    % Assumes string follows nvarFormatStr (as enforced by checkfield)
    options.MaxIter = nvars*sscanf(options.MaxIter, nvarFormatStr);
end

% Convert UseParallel to a boolean stored in SerialUserFcn
options.SerialUserFcn = ~validateopts_UseParallel(options.UseParallel,true,true);

% CreationFcn - only the function handle no additional arguments
options.CreationFcn = functionHandleOrCell('CreationFcn',options.CreationFcn);

% HybridFcn
if ~isempty(options.HybridFcn)
    [options.HybridFcn,options.HybridFcnArgs] = functionHandleOrCell('HybridFcn',options.HybridFcn);
    hybridFcnName = func2str(options.HybridFcn);
    
    unconstrainedHybridFcns = {'fminsearch','fminunc','patternsearch'};
    constrainedHybridFcns = {'fmincon','patternsearch'};
    allHybridFcns = union(unconstrainedHybridFcns,constrainedHybridFcns);

    stringSet('HybridFcn',hybridFcnName,allHybridFcns);
       
    bounded = any(isfinite(lb)) || any(isfinite(ub));
        
    % Check for a valid hybrid function for constrained problems
    if bounded && ~any(strcmpi(hybridFcnName,constrainedHybridFcns))
        msg = getString(message('globaloptim:validate:NotConstrainedHybridFcn', ...
                upper(hybridFcnName),strjoin(upper(constrainedHybridFcns),', ')));
        error('globaloptim:particleswarm:NotConstrainedHybridFcn',msg);
    elseif ~bounded && ~any(strcmpi(hybridFcnName,unconstrainedHybridFcns))
        msg = getString(message('globaloptim:validate:NotUnconstrainedHybridFcn', ...
                upper(hybridFcnName),strjoin(upper(unconstrainedHybridFcns),', ')));
        error('globaloptim:particleswarm:NotUnconstrainedHybridFcn',msg);
    end
    
    % If the user has set a hybrid function, they can specify options for the
    % hybrid function. If a user has passed a SolverOptions object for these
    % options, convert the options object to a structure. Note that we will not
    % warn here if a user specifies a solver with a different solver's options.
    if ~isempty(options.HybridFcnArgs) ...
            && isa(options.HybridFcnArgs{1}, 'optim.options.SolverOptions')
        % It is possible for a user to pass in a vector of options to the
        % solver. Silently use the first element in this array.
        options.HybridFcnArgs{1} = options.HybridFcnArgs{1}(1);
        
        % Extract the options structure
        options.HybridFcnArgs{1} = extractOptionsStructure(options.HybridFcnArgs{1});
    end
end

% ObjFcn
if ~isempty(objfcn)
    [objfcn,objFcnArgs] = functionHandleOrCell('ObjFcn',objfcn);
    if ~isempty(objFcnArgs)
        % Only need to create the anonymous function if there are
        % extra arguments.
        objfcn = createAnonymousFcn(objfcn,objFcnArgs);
    end
    % If necessary, create a function handle that enforces function value
    % checks.
    if strcmpi(options.FunValCheck, 'on')
        objfcnCell = optimfcnchk(objfcn,'particleswarm',nvars,true);
        objfcn = objfcnCell{3};
    end
else
    % This should only happen when called by psooutput
    objfcn = [];
end

% InitialSwarmSpan
options.InitialSwarmSpan = rangeCorrection(nvars,options.InitialSwarmSpan);

% Make sure that initial particles are consistent with nvars
if ~isempty(options.InitialSwarm) && size(options.InitialSwarm,2) ~= nvars
    error(message('globaloptim:particleswarm:wrongSizeInitialSwarm'));
end
end % validateOptions
