%
% Hybrid Optimization Design Approach of Asymmetric
% Base-Isolation Coupling System for Twin Buildings
%
% Optimization Code
%
% Wonsuk Park and Seung-Yong Ok
%
% July 2020
% 
%

close all;
clear;
clc;
rng('shuffle');
warning('off');
global fcncall Obj_history nvars Niter 
%% -----------------------------------------
% User Control Variables
%
% population
PopulationSize = 240; %240
minPoulationSize = round(0.2*PopulationSize);
maxNoOfChange = round(0.4*minPoulationSize);

% IterationPjh
maxNoIter = 300;
graceNoIter = round(0.01*maxNoIter);
%------------------------------------------



%% Initialization for Problem
% elapsed time
Total_etime = 0;
% parallel processing
% delete(gcp('nocreate'));
% parpool(4);

% Obejective Fucntion
fcncall = 0;
Obj_history = zeros(PopulationSize*maxNoIter+100,15);
objFcn = @fitness_tt;


%
% design variables for fitness_tt (Twin Tower)
%
% x1 ~x20 : C coeff. value for the Viscous Dampers 1~20 building A
% x21~x40 : C coeff. value for the Viscous DampersVD 1~20 building B
% x41     : C coeff. value for the Connection Viscous Damper
% x42,43  : (k) and (xi) value for the base isolator system of building B
%
% Bounds
% x1~x41  : [0 1]*10^8
% x42     : [0.0001 1]*10^9 [N/m]
% x43     : [0.02 0.5] [%]
%
nvars = 43;      % no.(dim) of variables
lb = [zeros(1,41) 0.0001 0.02];   % lower bound
ub = [ones(1,41) 1 0.5];   % upper bound


%% Evaluate initial population
% P0(PopulationSize,nvars);
P0 = initPopulation(nvars,lb,ub,PopulationSize-1);    % Initial pop P0
P0(PopulationSize,:)=[0.35*ones(1,41) 0.01 0.2];      % Uniform distribution design

tic
fprintf('---------------------------------\nStarting Initialization\n');
Fval0 = feval(objFcn,P0);
Itime = toc;

% Elapsed time
H_itime = floor(Itime/3600);
M_itime = floor((Itime - (H_itime*3600))/60);
S_itime = Itime - H_itime*3600 - M_itime*60;

fprintf('End of Initialization in %dh %dm %4.2fs \n---------------------------------\n\n',H_itime,M_itime,S_itime);

% for single output function only >>
if (size(Fval0,1) == 1)
    Fval0 = Fval0';
end
% << for single output function only 

%% set PI0
nt = 3; % no. of technique
nPopv = PopulationSize/nt*ones(1,nt);
maxdelnPop = round(nPopv(1)*0.1);

%% Initilization Techniques
%
% T1 : PSO
nPopT1 = nPopv(1);
popT1 = P0(1:nPopT1,:);
fvalT1 = Fval0(1:nPopT1,:);
IndividualBestPositions = popT1;
IndividualBestFvals = fvalT1;

pso_userOptions = optimoptions('particleswarm'); % default options
[pso_options, objFcn] = validateOptions(pso_userOptions, nvars, objFcn, lb, ub);
pso_options.Verbosity = 0;
pso_options.UseParallel = 1;
pso_options.SerialUserFcn = 1;
pso_options.Vectorized = 'on';
pso_options.SwarmSize = nPopT1;
minNeighborhoodSize = max(2,floor(nPopT1*pso_options.MinFractionNeighbors));
minInertia = pso_options.InertiaRange(1);
maxInertia = pso_options.InertiaRange(2);
isVectorized = strcmp(pso_options.Vectorized, 'on');

vmax = min(ub-lb, pso_options.InitialSwarmSpan);
Velocities = repmat(-vmax,nPopT1,1) + ...
    repmat(2*vmax,nPopT1,1) .* rand(nPopT1,nvars);
bestFvals = min(fvalT1);
bestFvalsWindow = nan(pso_options.StallIterLimit, 1);
% Initialize adaptive parameters:
%   initial inertia = maximum *magnitude* inertia
%   initial neighborhood size = minimum neighborhood size
adaptiveInertiaCounter = 0;
if all(pso_options.InertiaRange >= 0)
    adaptiveInertia = maxInertia;
elseif all(pso_options.InertiaRange <= 0)
    adaptiveInertia = minInertia;
else
    % checkfield should prevent InertiaRange from having positive and
    % negative vlaues.
    assert(false, 'globaloptim:particleswarm:invalidInertiaRange', ...
        'The InertiaRange option should not contain both positive and negative numbers.');
end
adaptiveNeighborhoodSize = minNeighborhoodSize;

%%
% T2 : GA

nPopT2= nPopv(2);
popT2 = P0(nPopT1+1:nPopT1+nPopT2,:);
fvalT2 = Fval0(nPopT1+1:nPopT1+nPopT2,:);

fun = objFcn;
Aineq = [];
bineq = [];
Aeq = [];
beq = [];
nonlcon = [];
intcon = [];
ga_options = [];
user_options =[];

defaultopt = struct('PopulationType', 'doubleVector', ...
    'PopInitRange', [], ... 
    'PopulationSize', '50 when numberOfVariables <= 5, else 200', ... 
    'EliteCount', '0.05*PopulationSize', ...  
    'CrossoverFraction', 0.8, ...
    'MigrationDirection','forward', ...
    'MigrationInterval',20, ...
    'MigrationFraction',0.2, ...
    'Generations', '100*numberOfVariables', ...
    'TimeLimit', inf, ...
    'FitnessLimit', -inf, ...
    'StallTest', 'averageChange', ... 
    'StallGenLimit', 50, ...
    'StallTimeLimit', inf, ...
    'TolFun', 1e-6, ...
    'TolCon', 1e-3, ...
    'InitialPopulation',[], ...
    'InitialScores', [], ...
    'NonlinConAlgorithm', 'auglag', ...    
    'InitialPenalty', 10, ...
    'PenaltyFactor', 100, ...
    'PlotInterval',1, ...
    'CreationFcn',@gacreationuniform, ...
    'FitnessScalingFcn', @fitscalingrank, ...
    'SelectionFcn', @selectionstochunif, ... 
    'CrossoverFcn',@crossoverscattered, ...
    'MutationFcn',{{@mutationgaussian 1  1}}, ...
    'HybridFcn',[], ...
    'Display', 'final', ...
    'PlotFcns', [], ...
    'OutputFcns', [], ...
    'Vectorized','on', ...
    'UseParallel', true);


% Prepare the options for the solver
ga_options = prepareOptionsForSolver(ga_options, 'ga');
if iscell(fun)
    FitnessFcn = fun{1};
else
    FitnessFcn = fun;
end
defaultopt.PopInitRange = [-10;10];
user_options = ga_options;
ga_options = defaultopt;
ga_options = gaoptimset(defaultopt,ga_options);
ga_options.UserSpecPopInitRange = isa(user_options, 'struct') && ...
    isfield(user_options, 'PopInitRange') && ~isempty(user_options.PopInitRange);
ga_options.MultiObjective = false;

[ga_x,ga_fval,exitFlag,output,ga_population,scores,FitnessFcn,nvars,Aineq,bineq,Aeq,beq,lb,ub, ...
    NonconFcn,ga_options,Iterate,type] = gacommon(nvars,fun,Aineq,bineq,Aeq,beq,lb,ub, ...
                                               nonlcon,intcon,ga_options,user_options);

% Turn constraints into right size if they are empty.
if isempty(Aineq)
    Aineq = zeros(0,nvars);
end
if isempty(bineq)
    bineq = zeros(0,1);
end
if isempty(Aeq)
    Aeq = zeros(0,nvars); 
end
if isempty(beq)
    beq = zeros(0,1);
end

% Initialize output args
ga_x = []; ga_fval = []; exitFlag = [];
LinearConstr = ga_options.LinearConstr;
GenomeLength = nvars;
% Create initial state: population, scores, status data
ga_popSize = nPopT2;
ga_options.InitialPopulation = P0(nPopT2+1:end,:);
ga_options.PopulationSize = ga_popSize;
ga_state.Population = P0(nPopT2+1:end,:);
ga_state.Score = Fval0(nPopT2+1:end,:);
ga_state.FunEval = 0;  
% A variety of data used in various places
ga_state.Generation = 0;		% current generation counter
ga_state.StartTime = tic;	    % current clock time
ga_state.StopFlag = []; 		% reason for termination
ga_state.LastImprovement = 1;	% generation stall counter
ga_state.LastImprovementTime = ga_state.StartTime;	% time stall counter
ga_state.Best = [];            % best score in every generation
ga_state.how = '';
ga_state.FunEval = 0;

ga_state.Expectation = zeros(ga_popSize,1);  % expection of individuals
ga_state.Selection = zeros(ga_popSize,1);       % selection indices

%%
% T3 : HS

nPopT3= nPopv(3);
popT3 = P0(nPopT1+nPopT2+1:end,:);
fvalT3 = Fval0(nPopT1+nPopT2+1:end,:);

%%%%%%%%%%%
% Step 1 : Initialization of SAH(PSO)S paramenters
%%%%%%%%%%%
% nvars          % No. of the decision variables
HMS = nPopT3;   % No. of Harmony Memory Size (similar to the pop. size in EA)
HMCR = 0.9;     % Harmony Memory Considering Rate  0.5<< HMCR <1.0
PARmin = 0.3;   % Pitch Adjusting Rate 0.2~0.4
PARmax = 0.7;   % Pitch Adjusting Rate 0.2~0.4

NI = maxNoIter;     % Max. no. of generations
% T = 1000;       % No. iteration for PSO

xminv = -100*ones(1,nvars); % LB
xmaxv = 100*ones(1,nvars);  % UB
x_new = ones(1,nvars);      % place holding

%%%%%%%%%%%
% Step 2b : Harmony Memory initialization
%%%%%%%%%%%

HM = [popT3 fvalT3];


%% main loop
ExitFlag = 0;

Niter = 0;
currPop = P0;
currFval = Fval0;

prev_nPopT1 = nPopT1;
prev_nPopT2 = nPopT2;
prev_nPopT3 = nPopT3;

best_fval_history = zeros(maxNoIter,1);
mean_fval_history = zeros(maxNoIter,1);

best_T1fval_history = zeros(maxNoIter,1);
best_T2fval_history = zeros(maxNoIter,1);
best_T3fval_history = zeros(maxNoIter,1);

mean_T1fval_history = zeros(maxNoIter,1);
mean_T2fval_history = zeros(maxNoIter,1);
mean_T3fval_history = zeros(maxNoIter,1);

nPopT1_history = zeros(maxNoIter,1);
nPopT2_history = zeros(maxNoIter,1);
nPopT3_history = zeros(maxNoIter,1);

% Start    
while(~ExitFlag)
    tic
    Niter = Niter + 1;
    
    % Update Quaility
    [sfvalT1,~]=sort(fvalT1,'ascend');
    [sfvalT2,~]=sort(fvalT2,'ascend');
    [sfvalT3,~]=sort(fvalT3,'ascend');
    Q1 = mean(sfvalT1(1:round(nPopT1*0.25)));
    Q2 = mean(sfvalT2(1:round(nPopT2*0.25)));
    Q3 = mean(sfvalT3(1:round(nPopT3*0.25)));

    if Niter > graceNoIter

        % Update Participation ratio
        Qv = [Q1 Q2 Q3];
        [sQv,idxQ] = sort(Qv,'ascend');
        
        q_winner = idxQ(1);
        q_loser = idxQ(3);
        q_middle = idxQ(2);
        
        xi = 4;
        delq = min(maxdelnPop,round(xi*(sQv(3)-sQv(1))/sQv(3)*nPopv(q_winner)));
        nPopv(q_winner) = nPopv(q_winner) + delq;
        nPopv(q_loser) = nPopv(q_loser) - delq;

        if nPopv(q_loser) < minPoulationSize
            nPopv(q_loser) = minPoulationSize;
            nPopv(q_winner) = PopulationSize - minPoulationSize -nPopv(q_middle);
        end

    end
    nPopT1=nPopv(1);
    nPopT2=nPopv(2);
    nPopT3=nPopv(3);

    
    fprintf('Iteration No: %d\n',Niter);
    fprintf('T1: %d   T2: %d   T3: %d\n',nPopT1,nPopT2,nPopT3);
    fprintf('Q1: %f   Q2: %f   Q3: %f\n',Q1,Q2,Q3);

    %---------------------------
    % Technique 1 : PSO
    %
    
    % Population Selection
    popT1 = currPop(1:prev_nPopT1,:);
    fvalT1 = currFval(1:prev_nPopT1,:);
    popTrest = currPop(prev_nPopT1+1:end,:);
    fvalTrest = currFval(prev_nPopT1+1:end,:);
    
    if Niter > graceNoIter
        
        cidx = fvalTrest < min(fvalT1);
        no_change = min(sum(cidx),maxNoOfChange);
        cidx = randperm(sum(cidx),no_change);
        if no_change > 0
            [temp,idx]=sort(fvalT1,'descend');            
            
            if no_change <= nPopT1
                popT1(idx(1:no_change),:)=popTrest(cidx,:);
                fvalT1(idx(1:no_change),:)=fvalTrest(cidx,:);
                IndividualBestPositions(idx(1:no_change),:)=popTrest(cidx,:);
                IndividualBestFvals(idx(1:no_change),:)=fvalTrest(cidx,:);
            else
                temp1 = popTrest(cidx,:);
                temp2 = fvalTrest(cidx,:);
                popT1(idx(1:nPopT1),:)=temp1(1:nPopT1,:);
                fvalT1(idx(1:nPopT1),:)=temp2(1:nPopT1,:);
                IndividualBestPositions(idx(1:nPopT1),:)=temp1(1:nPopT1,:);
                IndividualBestFvals(idx(1:nPopT1),:)=temp2(1:nPopT1,:);
            end
        end
            
        if (nPopT1 < prev_nPopT1)
            ncut = prev_nPopT1 - nPopT1;
            [temp,idx]=sort(fvalT1,'descend');
            popT1(idx(1:ncut),:)=[];
            fvalT1(idx(1:ncut),:)=[];
            IndividualBestPositions(idx(1:ncut),:)=[];
            IndividualBestFvals(idx(1:ncut),:)=[];
            Velocities(idx(1:ncut),:)=[];
            
        elseif (nPopT1 > prev_nPopT1)
            nadd = nPopT1 - prev_nPopT1;
            idx = randperm(PopulationSize-nPopT1,nadd);
            popT1(prev_nPopT1+1:nPopT1,:)=popTrest(idx,:);
            fvalT1(prev_nPopT1+1:nPopT1,:)=fvalTrest(idx,:);
            IndividualBestPositions(prev_nPopT1+1:nPopT1,:)=popTrest(idx,:);
            IndividualBestFvals(prev_nPopT1+1:nPopT1,:)=fvalTrest(idx,:);
            Velocities(prev_nPopT1+1:nPopT1,:)=repmat(-vmax,nadd,1) + ...
                repmat(2*vmax,nadd,1) .* rand(nadd,nvars);

        end
    end
 
  
    % Making offspring
    [offSpringT1,Velocities] = mosstep_pso(nPopT1,popT1,fvalT1,objFcn,nvars,lb,ub,...
        IndividualBestPositions,IndividualBestFvals,Velocities,...
        adaptiveNeighborhoodSize,adaptiveInertia,bestFvals,pso_options);
    
    % Updating
    if isVectorized
        fvalT1 = objFcn(offSpringT1);
    else
        fvalT1 = fcnvectorizer(offSpringT1, objFcn, 1, pso_options.SerialUserFcn);
    end
    
    % for single output function only >>
    if (size(fvalT1,1) == 1)
        fvalT1 = fvalT1';
    end
    % << for single output function only
    
    % Remember the best fvals and positions
    tfImproved = fvalT1 < IndividualBestFvals;
    IndividualBestFvals(tfImproved) = fvalT1(tfImproved);
    IndividualBestPositions(tfImproved, :) = offSpringT1(tfImproved, :);
    bestFvalsWindow(1+mod(Niter-1,pso_options.StallIterLimit)) = min(IndividualBestFvals);
    minNeighborhoodSize = max(2,floor(nPopT1*pso_options.MinFractionNeighbors));
    newBest = min(IndividualBestFvals);
    if isfinite(newBest) && newBest < bestFvals
        bestFvals = newBest;
        adaptiveInertiaCounter = max(0, adaptiveInertiaCounter-1);
        adaptiveNeighborhoodSize = minNeighborhoodSize;
    else
        adaptiveInertiaCounter = adaptiveInertiaCounter+1;
        adaptiveNeighborhoodSize = min(nPopT1, adaptiveNeighborhoodSize+minNeighborhoodSize);
    end

    if adaptiveInertiaCounter < 2
        adaptiveInertia = max(minInertia, min(maxInertia, 2*adaptiveInertia));
    elseif adaptiveInertiaCounter > 5
        adaptiveInertia = max(minInertia, min(maxInertia, 0.5*adaptiveInertia));
    end
 
    
    %---------------------------
    % Technique 2 : GA
    %

    % Population Selection
    p2_start = prev_nPopT1 + 1;
    p2_end = p2_start + prev_nPopT2 -1;
    popT2 = currPop(p2_start:p2_end,:);
    fvalT2 = currFval(p2_start:p2_end,:);
    popTrest = currPop([1:nPopT1 p2_end+1:end],:);
    fvalTrest = currFval([1:nPopT1 p2_end+1:end],:);
    
     if Niter > graceNoIter
         
         cidx = fvalTrest < min(fvalT2);
         no_change = min(sum(cidx),maxNoOfChange);
         cidx = randperm(sum(cidx),no_change);
         if no_change > 0
             [temp,idx]=sort(fvalT2,'descend');
             if no_change <= nPopT2
                 popT2(idx(1:no_change),:)=popTrest(cidx,:);
                 fvalT2(idx(1:no_change),:)=fvalTrest(cidx,:);
             else
                 temp1 = popTrest(cidx,:);
                 temp2 = fvalTrest(cidx,:);
                 popT2(idx(1:nPopT2),:)=temp1(1:nPopT2,:);
                 fvalT2(idx(1:nPopT2),:)=temp2(1:nPopT2,:);
             end
         end
         if (nPopT2 < prev_nPopT2)
             ncut = prev_nPopT2 - nPopT2;
             [temp,idx]=sort(fvalT2,'descend');
             popT2(idx(1:ncut),:)=[];
             fvalT2(idx(1:ncut),:)=[];
         elseif (nPopT2 > prev_nPopT2)
             nadd = nPopT2 - prev_nPopT2;
             idx = randperm(PopulationSize-nPopT2,nadd);
             popT2(prev_nPopT2+1:nPopT2,:)=popTrest(idx,:);
             fvalT2(prev_nPopT2+1:nPopT2,:)=fvalTrest(idx,:);
         end
         
         best = min(fvalT2);
         ga_state.Best(Niter) = best;
    end
     
    ga_popsize = nPopT2;
    ga_state.Population = popT2;
    ga_state.Score = fvalT2;
        
    % ---------------------------------------------------------------------
    % new aux pop by GA
    %
    ga_state.Generation = ga_state.Generation + 1;
    % Repeat for each subpopulation (element of the populationSize vector)
    offset = 0;
    thisPopulation = 1 + (offset:(offset + nPopT2 - 1));
    [score,ga_population,ga_state] = mos_stepGA(nPopT2,fvalT2,popT2,ga_options,ga_state,GenomeLength,FitnessFcn);
    % Store the results for this sub-population
    ga_state.Population(thisPopulation,:) = ga_population;
    ga_state.Score(thisPopulation) = score;
    %offset = offset + nPopT2;
    % Remember the best score
    best = min(ga_state.Score);
    generation = ga_state.Generation;
    ga_state.Best(generation) = best;
    % Keep track of improvement in the best
    if((generation > 1) && isfinite(best))
        if(ga_state.Best(generation-1) > best)
            ga_state.LastImprovement = generation;
            ga_state.LastImprovementTime = tic;
        end
    end
    % Do any migration
    ga_state = migrate(FitnessFcn,GenomeLength,ga_options,ga_state);
  
    offSpringT2 = ga_state.Population;
    fvalT2 = ga_state.Score;
    
    
    %---------------------------
    % Technique 3 : HS
    %

    % Population Selection
    p3_start = prev_nPopT1 + prev_nPopT2 + 1;
    p3_end = prev_nPopT1 + prev_nPopT2 + prev_nPopT3;
    % cherk size error
    if PopulationSize ~= p3_end
        fprintf('Error : PopulationSize ~= p3_end');
        return;
    end
    popT3 = currPop(p3_start:p3_end,:);
    fvalT3 = currFval(p3_start:p3_end,:);
    popTrest = currPop([1:nPopT1+nPopT2],:);
    fvalTrest = currFval([1:nPopT1+nPopT2],:);
    
    
    if Niter > graceNoIter
        
        cidx = fvalTrest < min(fvalT3);
        no_change = min(sum(cidx),maxNoOfChange);
        cidx = randperm(sum(cidx),no_change);
        if no_change > 0
            [temp,idx]=sort(fvalT3,'descend');
            if no_change <= nPopT3
                popT3(idx(1:no_change),:)=popTrest(cidx,:);
                fvalT3(idx(1:no_change),:)=fvalTrest(cidx,:);
            else
                temp1 = popTrest(cidx,:);
                temp2 = fvalTrest(cidx,:);
                popT3(idx(1:nPopT3),:)=temp1(1:nPopT3,:);
                fvalT3(idx(1:nPopT3),:)=temp2(1:nPopT3,:);
            end
        end
        if (nPopT3 < prev_nPopT3)
            ncut = prev_nPopT3 - nPopT3;
            [temp,idx]=sort(fvalT3,'descend');
            popT3(idx(1:ncut),:)=[];
            fvalT3(idx(1:ncut),:)=[];
        elseif (nPopT3 > prev_nPopT3)
            nadd = nPopT3 - prev_nPopT3;
            idx = randperm(PopulationSize-nPopT3,nadd);
            popT3(prev_nPopT3+1:nPopT3,:)=popTrest(idx,:);
            fvalT3(prev_nPopT3+1:nPopT3,:)=fvalTrest(idx,:);
        end

    end
    
    % ---------------------------------------------------------------------
    % new aux pop by HS
    % 
    HM = [popT3 fvalT3];
    HMS = size(HM,1);
    %%%%%%%%%%%
    % Improvise a new harmony
    %%%%%%%%%%%
    t = Niter;
    NI = maxNoIter;
    
    % PAR
    PARt = PARmin + (PARmax - PARmin)/(1+exp(20*t/NI-10));
    
    % Construction of new solution candidate x_new
    for ii = 1: nvars
        if (rand < HMCR)
            % select the best and worst in HM
            [best_f,idx_best]=min(HM(:,nvars+1));
            [worst_f,idx_worst]=max(HM(:,nvars+1));
            x_best = HM(idx_best,1:nvars);
            x_worst = HM(idx_worst,1:nvars);
            
            % select random descision vector xi_new from HM
            aa = round(1 + (HMS-1)*rand);
            xa = HM(aa,1:nvars);
            xi_new = xa;
            xj_new = xa + rand(1,nvars).*(x_best - xa);
            for kk = 1:nvars
                xj_new(1,kk) = min([ub(kk) xj_new(1,kk)]);
                xj_new(1,kk) = max([lb(kk) xj_new(1,kk)]);
            end

            f_xa = feval(objFcn,xa);
            f_xj = feval(objFcn,xj_new);
            if f_xj <= f_xa
                HM(idx_worst,:)=[xj_new f_xj];
            end
            
            % Pitch Adjusting
            if rand < PARt
                % Bandwidth and Adjusting
                BWi = median(HM(:,ii));
                xi_new(1,ii)=xi_new(1,ii)+(2*rand-1)*BWi;
                xi_new(1,ii) = min([ub(ii) xi_new(1,ii)]);
                xi_new(1,ii) = max([lb(ii) xi_new(1,ii)]);
                
                f_xi = feval(objFcn,xi_new);
                if f_xi <= f_xa
                    HM(aa,:)=[xi_new f_xi];
                end
            end
        else
            xi_new(1,ii)=xminv(ii)+rand*(xmaxv(ii)-xminv(ii));
        end
        
        % Add mutation strategy
        if rand > 1-PARt
            R = xi_new(1,ii) - HM(:,ii);
            if max(R) < xi_new(1,ii)*1E-3
                xi_new(1,ii) = xi_new(1,ii)*(1+randn*5E-2);
                if max(R) < xi_new(1,ii)*1E-5
                    xi_new(1,ii) = xi_new(1,ii)*(1+randn*1E-2);
                end
            end
        end
        
        % new solution candidate x_new
        x_new(1,ii) = min([ub(ii) xi_new(1,ii)]);
        x_new(1,ii) = max([lb(ii) xi_new(1,ii)]);
        
    end
    
    %%%%%%%%%%%%%
    % Step 4 Update HM
    %%%%%%%%%%%%%
    
    % select the best and worst in HM
    [best_f,idx_best]=min(HM(:,nvars+1));
    [worst_f,idx_worst]=max(HM(:,nvars+1));
    x_best = HM(idx_best,1:nvars);
    x_worst = HM(idx_worst,1:nvars);
    
    % generate a perturbed descision vector xp_new
    % and replace x_new if xp_new is better than x_new
    xp_new = x_new + rand(1,nvars).*(x_best-x_new);
    
    parfor ii = 1:nvars
        xp_new(1,ii) = min([ub(ii) xp_new(1,ii)]);
        xp_new(1,ii) = max([lb(ii) xp_new(1,ii)]);
    end

    f_x = feval(objFcn,x_new);
    f_xp = feval(objFcn,xp_new);
    if f_xp <= f_x
        x_new = xp_new;
        f_x = f_xp;
    end
    
    % Update HM if the new candidate x_new is better than the worst
    if f_x <= worst_f
        HM(idx_worst,:)=[x_new f_x];
    end
    
    % Store and print
    avef(t) = mean(HM(:,nvars+1));
    minf(t) = min(HM(:,nvars+1));
   
    offSpringT3 = HM(:,1:nvars);
    fvalT3 = HM(:,end);
    
    %----------------------------
    % update
    prev_nPopT1 = nPopT1;
    prev_nPopT2 = nPopT2;
    prev_nPopT3 = nPopT3;

    %---------------------------
    % Combine 
    %
    currPop = [offSpringT1; offSpringT2; offSpringT3];
    currFval =[fvalT1; fvalT2; fvalT3];

    % Store history
    best_fval_history(Niter,1) = min(currFval);
    mean_fval_history(Niter,1) = mean(currFval);
    best_T1fval_history(Niter,1) = min(fvalT1);
    mean_T1fval_history(Niter,1) = mean(fvalT1);
    best_T2fval_history(Niter,1) = min(fvalT2);
    mean_T2fval_history(Niter,1) = mean(fvalT2);
    best_T3fval_history(Niter,1) = min(fvalT3);
    mean_T3fval_history(Niter,1) = mean(fvalT3);
    nPopT1_history(Niter,1) = nPopT1;
    nPopT2_history(Niter,1) = nPopT2;
    nPopT3_history(Niter,1) = nPopT3;
    % Stop Criteria
    if Niter > maxNoIter -1
        ExitFlag = 1;
    end
    %% Time
    etime = toc;
    Total_etime = Total_etime + etime;
    
    % Elapsed time
    H_etime = floor(Total_etime/3600);
    M_etime = floor((Total_etime - (H_etime*3600))/60);
    S_etime = Total_etime - H_etime*3600 - M_etime*60;
  
    % ETA
    rIter = maxNoIter - Niter;
    rtime = etime*rIter;
    H_rtime = floor(rtime/3600);
    M_rtime = floor((rtime - (H_rtime*3600))/60);
    S_rtime = rtime - H_rtime*3600 - M_rtime*60;
    fprintf('This generation : %4.2f sec.\n',etime);
    fprintf('Running         : %dh %dm %4.2fs \nETA             : %dh %dm %4.2fs \n---------------------------------\n',H_etime,M_etime,S_etime,H_rtime,M_rtime,S_rtime);
    save('Temp_MOS3tt.mat');     
    
end % end of while(~ExitFlag)
delete(gcp('nocreate'));
% 
%% Post processing
[minf,idx]=min(currFval);
Min_f = minf;
Opt_x = currPop(idx,:);

itv = 1:maxNoIter;
figure;
semilogy(itv,best_T1fval_history,'r-',itv,mean_T1fval_history,'r:',...
    itv,best_T2fval_history,'g-',itv,mean_T2fval_history,'g:',...
    itv,best_T3fval_history,'b-',itv,mean_T3fval_history,'b:',...
    itv,best_fval_history,'k-',itv,mean_fval_history,'k:');
xlabel('Generation');
ylabel('Objective function value');
legend('Best','Mean','T1:PSO best','T1:PSO mean',...
    'T2:GA best','T2:GA mean','T3:HS best','T3:HS mean');

figure;
plot(itv,nPopT1_history,itv,nPopT2_history,itv,nPopT3_history);
xlabel('Generation');
ylabel('No. of Population');
legend('T1:PSO','T2:GA','T3:HS');

%% Optimal 

%% save result
sfname1 = sprintf('Res_MOS3tt_%s',datestr(datetime('now'),'yymmdd_HHMMss'));
save(sfname1);
sfname2 = sprintf('Optx_MOS3tt_%s',datestr(datetime('now'),'yymmdd_HHMMss'));
save(sfname2,'Opt_x');



