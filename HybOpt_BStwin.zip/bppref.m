% parameters of basic preference function generation

function [x,y]=bppref(YPfmax,r,n,alpha)

x=zeros(1,n);
y=zeros(1,n);
x(1)=(YPfmax/alpha^(r-1))^(1/n);
for j=2:r
    x(j)=x(1)*(alpha^(j-1))^(1/n);
end
for j=1:r
    y(j)=x(1)^n*alpha^(j-1);
end